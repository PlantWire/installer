<?php
return [

    /*
    |--------------------------------------------------------------------------
    | Humidity Sensor Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are translations for texts used in humidity sensor classes.
    | This is a custom pWire project localization file.
    |
    */

    'measurement_requested' => 'Requested a new measurement for sensor ":Sensor_name"',
    'removed' => 'Humidity Sensor was successfully removed.',
    'updated' => 'Humidity Sensor was successfully updated.',
];
