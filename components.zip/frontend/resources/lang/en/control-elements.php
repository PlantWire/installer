<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Control Elements Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are translations for texts used in generic
    | control elements.
    | This is a custom pWire project localization file.
    |
    */

    'return_to_dashboard' => 'Return to Dashboard',
    'save_changes' => 'Save Changes',
    'no_changes_when_empty' => 'leave empty to not change the current :value_name',

];
