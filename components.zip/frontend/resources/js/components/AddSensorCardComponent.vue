<template>
    <div class="column is-one-third">
        <div class="card">
            <header class="card-header">
                <p class="card-header-title">
                     New Sensor
                </p>
            </header>

            <div class="card-content">
                <div class="content">
                    <a class="button is-primary" href="/create_sensor">
                         Add a new sensor
                    </a>
                </div>
            </div>

        </div>
    </div>
</template>

