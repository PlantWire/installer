<template>
    <div class="column is-full">
        <div class="column is-three-fifths is-offset-one-fifth">

            <h1 class="title is-1 is-spaced">Welcome to pWire!</h1>

            <h2 class="subtitle is-3 is-spaced">

                <i class="fas fa-leaf"></i> Every year, countless plants and flowers die because of improper treatment.
                <br/><br/>
                <i class="fas fa-smile-beam"></i> pWire wants to make your plants happy.
                <br/><br/>
                <i class="fas fa-tint"></i> It measures the humidity in the pot so you know when to add water.
                <br/><br/>
            </h2>

            <h2 class="subtitle is-5">
                Please log in
            </h2>

        </div>
    </div>
</template>

