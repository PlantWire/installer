<template>
    <div class="column is-full">
        <div class="column is-three-fifths is-offset-one-fifth">

            <h1 class="title is-1 is-spaced has-text-centered">You have no sensors yet</h1>

            <a class="button is-primary is-medium is-fullwidth" href="/create_sensor">
                Click here to add your first sensor
            </a>

        </div>
    </div>
</template>

