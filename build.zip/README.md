# Pwire Installer
A script which helps user install the pwire-server on a NanoPi.
- For help: `sudo installer.sh --help`